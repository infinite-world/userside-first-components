import React, { Component } from "react";
import "./Userdata.scss";
import Image from "./image/WhatsApp Image 2020-07-06 at 12.49.18 PM.jpg";
import Usernavbar from "../usernavbar/Usernavbar";

class Userside extends Component {
  render() {
    return (
      <div>
        <Usernavbar />
        <div class="container">
          <div class="main-body">
            <div class="row gutters-sm">
              <div class="col-md-4 mb-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex flex-column align-items-center text-center">
                      <img
                        src={Image}
                        alt="Admin"
                        class="rounded-circle"
                        width="150"
                      />
                      <div class="mt-3">
                        <h4>Abdul Rehman</h4>
                        <p class="text-muted mb-1">Front End Developer</p>
                        <p class="text-muted font-size-sm">
                          Nizamabad Faisalabad, Madena Town
                        </p>
                        <button
                          type="button"
                          class="btn btn-primary btn-lg btn-block"
                        >
                          Block level button
                        </button>
                        <button
                          type="button"
                          class="btn btn-secondary btn-lg btn-block"
                        >
                          Block level button
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Userside;
